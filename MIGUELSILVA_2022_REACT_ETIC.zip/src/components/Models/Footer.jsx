import React from 'react'

export default function Footer() {
    return (
        <>
            <hr className='hr-color'/>
            <div className='footer ms-3 text-center'>
                © 2019 MichaelDevs All rights reserved.
            </div>
        </>
    )
}
